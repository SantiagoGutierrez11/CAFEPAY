#  Sprint 1 - Avance del Sistema de Gestión de Recolectores

##  Entregables
-  Ejecutable funcional (Entrega_Ejecutable/CAFEPAY.exe)
-  Sistema completo de CRUD para recolectores
-  Interfaz gráfica profesional
-  Validaciones de datos

##  Funcionalidades Implementadas
- Registro de recolectores
- Modificación de recolectores  
- Consulta de recolectores
- Confirmaciones de operaciones
- Navegación entre vistas
- Validaciones de datos

##  Tecnologías
- .NET 6.0
- Windows Forms
- Oracle Database
- Git/GitHub

##  Ejecutable de Demo:
- **Archivo:** `Sprint1_Avance.zip`
- **Contenido:** Sistema completo de gestión de recolectores
- **Para ejecutar:** 
  1. Descargar y extraer el .zip
  2. Abrir la carpeta Entrega_Ejecutable
  3. Ejecutar `CAFEPAY.exe`
  4. La aplicación se abre en pantalla completa


###  Para probar:
1. **Registrar** → Botón "Registrar Recolector"
2. **Modificar** → Seleccionar fila + Botón "Modificar"
3. **Consultar** → Tabla principal